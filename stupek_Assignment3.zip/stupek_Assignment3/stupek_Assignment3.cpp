// stupek_Assignment3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

// Copper spool is $100
// Normal shipping is $10

// ocSpools = ordered copper spools
// scSpools = Stocked copper spools
// sSpools = Shipped spools  
// boSpools = Back ordered Spools
// sCharges = Shipping charges
// ocsPrice = Ordered copper spools price 
// rSpool = Rate per spool 


//function one prototype
void orderInfo(int& ocSpools, int& scSpools);
//function two prototype
void displayOrderInfo(int ocSpools, int scSpools, int sCharges = 10);


int main()
{
    int ocSpools, scSpools;
    int sCharges = 10;
    
    //Call for func 1
    orderInfo(ocSpools, scSpools);
    //Call for func 2 
    displayOrderInfo(ocSpools, scSpools, sCharges);

    //Exit
    return 0;

}

/********************************************************
* Function that asks for the number of spools ordered   *
* the number of spools in stock                         *
* *******************************************************/

void orderInfo(int& ocSpools, int& scSpools)
{
    cout << "Enter how many spools were ordered?:" << endl;
    cin >> ocSpools;

    cout << "Enter how many spools are in stock?:" << endl;
    cin >> scSpools;

}

/***************************************************************************************
* Function that recieves the values from func 1 as args to output the following:
* 1.Checks if there are any special shipping costs. 
* 2.Displays number of orderded spools that are ready to ship                
* 3.Displays the number of spools in backorder                                            *
* 4.Displays total price for spools ready to ship                                         *
* 5.Displays total shipping & handling fees **only for spools ready to ship**             *
* 6.Displays total price for order ready to ship                                          *
* ********************************************************************************/


void displayOrderInfo(int ocSpools, int scSpools, int sCharges)
{
    int boSpools, ocsPrice, sSpools;
    const int rSpool = 100;

    cout << "Any speical shipping costs (per spool rate) \n";
    cout << "above the standard $10.00/spool rate? (0 for no special costs):" << endl;
    cin >> sCharges;

    if (sCharges > 10) {
        cout << "Please confirm special shipping cost:" << endl;
        cin >> sCharges;
    }
    else {
        sCharges = 10;
    }

    // Check if there are enough spools in stock to fulfill the order
    if (ocSpools <= scSpools) {
        sSpools = ocSpools; // If there are enough set spools in shipment to the number ordered
        boSpools = 0; // and set back-ordered spools 0
    }
    else {
        sSpools = scSpools; // Set spools in shipment to the number in stock
        boSpools = ocSpools - scSpools; // calculate back-ordered spools
    }
    // Calculate ordered copper spools price
    ocsPrice = sSpools * rSpool;

    cout << "       *** Order Summary ***\n";
    cout << "Spools ordered :                " << ocSpools << endl;
    cout << "Spools in this shippment:       " << scSpools << endl;
    cout << "Spools in back order:           " << boSpools << endl;
    cout << "\n" << endl; 
    cout << "\n" << endl;
    cout << "Charges for this shipment\n";
    cout << "-------------------------" << endl;
    cout << "Spool Charges:         " << "$" << ocsPrice << endl;
    cout << "Shipping charges:      " << "$" << sCharges * sSpools << endl;
    cout << "Total charges:         " << "$" << ocsPrice + (sCharges * ocSpools) << endl;
}